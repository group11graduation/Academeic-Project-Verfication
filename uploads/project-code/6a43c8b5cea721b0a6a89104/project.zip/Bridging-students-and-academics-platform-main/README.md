### Bridging students and academics platform

A role-based web application built with PHP that streamlines task management between supervisors and students. The system allows supervisors to create and assign tasks, while students can view assigned tasks and submit their work online. Administrators have full control over user management, including creating and managing supervisor and student accounts. The application includes a secure authentication system with separate access levels for Admin, Supervisor, and Student roles.



## Group Members

      Name                          ID
1. Amina Ibrahim Saleh             C1221335
2. Asma Abdieisaq Maxamud          C1221334
3. Abdihakiin  gedi mohamed        C1221240
4. Rayaan Ahmed Hussian            C1220432