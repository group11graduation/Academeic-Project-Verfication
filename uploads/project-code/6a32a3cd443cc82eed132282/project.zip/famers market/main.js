// 1. Database (Sidii hore)
let products = [
    { id: 1, name: "Yaanyo Cusub", price: 20, img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTF2_5lA1FZTiBdJUm_xy2VmtN-bt4flO9GOHkez4Dq460BJ0K9MEUJfiE&s" },
    { id: 2, name: "Moos Bisil", price: 15, img: "https://images.unsplash.com/photo-1528825871115-3581a5387919?w=400" },
    { id: 3, name: "Basal Cas", price: 10, img: "https://images.unsplash.com/photo-1508747703725-719777637510?w=400" },
    { id: 4, name: "Baradho", price: 25, img: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400" },
    { id: 5, name: "Karooto Organic", price: 12, img: "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=400" },
    { id: 6, name: "Tufaax Cas", price: 30, img: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400" },
    { id: 7, name: "Baqli (Garlic)", price: 8, img: "https://images.unsplash.com/photo-1540148426945-6cf22a6b2383?w=400" },
    { id: 8, name: "Liin Macaan", price: 18, img: "https://images.unsplash.com/photo-1582979512210-99b6a53386f9?w=400" },
    { id: 9, name: "Sanjabiil", price: 22, img: "https://images.unsplash.com/photo-1550989460-0adf9ea622e2?w=400" }
];

let totalRevenue = 1240;
let orders = 18;
let editMode = false;

// 2. Render Market (Update: Added Edit and Delete buttons)
function renderMarket(items = products) {
    const grid = document.getElementById('productGrid');
    if (!grid) return;
    grid.innerHTML = ''; 
    items.forEach(p => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <img src="${p.img}" alt="${p.name}">
            <div class="p-info">
                <h3>${p.name}</h3>
                <p>Qiimaha: $${p.price}</p>
                <div class="card-actions">
                    <button class="btn-buy" onclick="buyProduct(${p.price}, '${p.name}')">Iibso</button>
                    <button class="btn-edit" onclick="editProduct(${p.id})">Beddel</button>
                    <button class="btn-delete" onclick="deleteProduct(${p.id})">Tirtir</button>
                </div>
            </div>
        `;
        grid.appendChild(card);
    });
}

// 3. CRUD: Delete (Tirtir)
function deleteProduct(id) {
    if(confirm('Ma hubtaa inaad tirtirto alaabtan?')) {
        products = products.filter(p => p.id !== id);
        renderMarket();
    }
}

// 4. CRUD: Edit (Beddel - Fill form)
function editProduct(id) {
    const p = products.find(prod => prod.id === id);
    document.getElementById('productId').value = p.id;
    document.getElementById('pName').value = p.name;
    document.getElementById('pPrice').value = p.price;
    document.getElementById('pImg').value = p.img;
    document.getElementById('submitBtn').innerText = "Cusboonaysii Alaabta";
    editMode = true;
    window.scrollTo(0, 500); // Scroll to form
}

// 5. Form Validation & CRUD: Add/Update
document.getElementById('productForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const id = document.getElementById('productId').value;
    const name = document.getElementById('pName').value.trim();
    const price = parseInt(document.getElementById('pPrice').value);
    const img = document.getElementById('pImg').value.trim();

    // Simple Validation
    if(name === "" || isNaN(price) || img === "") {
        alert("Fadlan buuxi dhammaan meelaha banaan!");
        return;
    }

    if(editMode) {
        // Update existing
        const index = products.findIndex(p => p.id == id);
        products[index] = { id: parseInt(id), name, price, img };
        editMode = false;
        document.getElementById('submitBtn').innerText = "Ku dar Suuqqa";
    } else {
        // Add new
        const newProduct = {
            id: Date.now(), // Unique ID
            name,
            price,
            img
        };
        products.push(newProduct);
    }

    this.reset();
    renderMarket();
});

// 6. Iibka iyo Chart-ka (Sidii hore)
window.buyProduct = function(price, name) {
    totalRevenue += price;
    orders += 1;
    document.getElementById('totalSales').innerText = `$${totalRevenue}`;
    document.getElementById('orderCount').innerText = orders;
    renderChart();
    alert(`Waad ku mahadsantahay iibshada ${name}!`);
};

function renderChart() {
    const chart = document.getElementById('salesChart');
    if (!chart) return;
    chart.innerHTML = ''; 
    const weeklySales = [
        { day: 'Isn', sales: 450 }, { day: 'Tal', sales: 700 }, 
        { day: 'Arb', sales: 300 }, { day: 'Kham', sales: 900 }, 
        { day: 'Jim', sales: totalRevenue }
    ];
    const maxVal = Math.max(...weeklySales.map(d => d.sales)) + 200;
    weeklySales.forEach(data => {
        const height = (data.sales / maxVal) * 100;
        const barWrapper = document.createElement('div');
        barWrapper.className = 'bar-wrapper';
        barWrapper.innerHTML = `
            <span class="bar-value">$${data.sales}</span>
            <div class="bar" style="height: ${height}%;"></div>
            <span class="bar-day">${data.day}</span>
        `;
        chart.appendChild(barWrapper);
    });
}

document.getElementById('searchInput').addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    const filtered = products.filter(p => p.name.toLowerCase().includes(term));
    renderMarket(filtered);
});

document.addEventListener('DOMContentLoaded', () => {
    renderMarket();
    renderChart();
});